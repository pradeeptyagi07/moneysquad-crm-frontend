// src/components/Leads/LeadsActionMenu.tsx
"use client";

import React from "react";
import { Menu, MenuItem, Typography, useTheme } from "@mui/material";
import {
  Visibility,
  Edit,
  FileCopy,
  Assignment,
  History,
  AttachMoney,
  Delete,
} from "@mui/icons-material";

export type UserRoleType = "admin" | "manager" | "partner" | "associate";

interface LeadsActionMenuProps {
  anchorEl: HTMLElement | null;
  open: boolean;
  onClose: () => void;
  onSelectAction: (action: string) => void;
  userRole: UserRoleType;
  currentStatus: string;
  currentStatusUpdatedAt?: string;
  disbursedData?: any;
  lenderType?: string | null;
}

const LeadsActionMenu: React.FC<LeadsActionMenuProps> = ({
  anchorEl,
  open,
  onClose,
  onSelectAction,
  userRole,
  currentStatus,
  currentStatusUpdatedAt,
  disbursedData,
  lenderType,
}) => {

  console.log("lendertype",lenderType)
  const theme = useTheme();
  const now = new Date();
  const updatedAt = currentStatusUpdatedAt ? new Date(currentStatusUpdatedAt) : null;
  const daysSince = updatedAt
    ? (now.getTime() - updatedAt.getTime()) / (1000 * 60 * 60 * 24)
    : 0;

  // Base set of all possible actions
  let items = [
    { icon: <Visibility />, label: "view" },
    { icon: <Edit />, label: "edit" },
    { icon: <FileCopy />, label: "duplicate" },
    { icon: <Assignment />, label: "assign" },
    { icon: <Edit />, label: "status" },
    { icon: <History />, label: "timeline" },
    { icon: <AttachMoney />, label: "disbursement" },
    { icon: <Delete />, label: "delete" },
  ];

  //
  //——— Common filters — do NOT hide “status” here for admin/manager ———
  //
  // only hide status if there’s truly no lenderType *and* the user is partner/associate
  if (!lenderType && (userRole === "partner" || userRole === "associate")) {
    items = items.filter(i => i.label !== "status");
  }

  // if it’s a brand-new, closed or expired deal, you also can’t change status
  if (["new lead", "closed", "expired"].includes(currentStatus)) {
    items = items.filter(i => i.label !== "status");
  }

  //
  //——— Admin ———
  //
  if (userRole === "admin") {
    // admin never sees “disbursement” until it’s been disbursed (i.e. status===disbursed)
    if (currentStatus !== "disbursed") {
      items = items.filter(i => i.label !== "disbursement");
    }
  }

  //
  //——— Manager ———
  //
  if (userRole === "manager") {
    // no delete or assign
    items = items.filter(i => i.label !== "delete" && i.label !== "assign");

    // only show disbursement *once* it’s actually disbursed
    if (currentStatus !== "disbursed") {
      items = items.filter(i => i.label !== "disbursement");
    }

    // once disbursed, you can no longer change status
    if (currentStatus === "disbursed") {
      items = items.filter(i => i.label !== "status");
    }

    // only allow edit if it’s still pending and <=30 days old
    if (currentStatus !== "pending" || daysSince > 30) {
      items = items.filter(i => i.label !== "edit");
    }
  }

  // Partner & Associate: very limited
  if (userRole === "partner" || userRole === "associate") {
    items = items.filter(
      i =>
        !["duplicate", "assign", "status", "disbursement"].includes(i.label)
    );
    if (currentStatus !== "new lead") {
      items = items.filter(i => !["edit", "delete"].includes(i.label));
    }
  }

  // Label mapper
  const getLabel = (label: string) => {
    if (label === "disbursement") {
      // managers always see plain "Disbursement"
      if (userRole === "manager") return "Disbursement";
      // others toggle to Edit if data exists
      return disbursedData ? "Edit Disbursement" : "Disbursement";
    }
    return label.charAt(0).toUpperCase() + label.slice(1);
  };

  return (
    <Menu
      anchorEl={anchorEl}
      open={open}
      onClose={onClose}
      PaperProps={{ sx: { borderRadius: 2 } }}
    >
      {items.map(({ icon, label }) => (
        <MenuItem
          key={label}
          onClick={() => {
            onSelectAction(label);
            onClose();
          }}
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1,
            px: 2,
            py: 1,
            "&:hover": { backgroundColor: theme.palette.action.hover },
          }}
        >
          {React.cloneElement(icon as any, {
            sx: { color: theme.palette.primary.main },
          })}
          <Typography variant="body2" sx={{ fontWeight: 500 }}>
            {getLabel(label)}
          </Typography>
        </MenuItem>
      ))}
    </Menu>
  );
};

export default LeadsActionMenu;
